package com.example.jobportal

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.jobportal.data.JobRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JobDetailsScreen(navController: NavController, jobId: Int?) {
    val job = jobId?.let { JobRepository.getJobById(it) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Job Details") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Filled.ArrowBack, "Back")
                    }
                }
            )
        },
        bottomBar = {
            Button(
                onClick = { navController.navigate("applyJob/${job?.id}") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text("Apply Now")
            }
        }
    ) { padding ->
        job?.let {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
            ) {
                item {
                    Text(
                        text = it.title,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(text = it.company, fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Location: ${it.location}")
                    Text("Salary: ${it.salary}")
                    Text("Type: ${it.type}")

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Description:", fontWeight = FontWeight.Bold)
                    Text(it.description)

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Requirements:", fontWeight = FontWeight.Bold)
                    it.requirements.forEach { req ->
                        Text("• $req")
                    }
                }
            }
        }
    }
}