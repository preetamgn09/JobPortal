package com.example.jobportal.data


data class Job(
    val id: Int,
    val title: String,
    val company: String,
    val location: String,
    val salary: String,
    val type: String,
    val description: String,
    val requirements: List<String>,
    val postedDate: String,
    val category: String
)

object JobRepository {
    val jobs = listOf(
        Job(
            id = 1,
            title = "Senior Android Developer",
            company = "TechCorp Solutions",
            location = "Bengaluru, Karnataka",
            salary = "₹15-25 LPA",
            type = "Full-time",
            description = "We are looking for an experienced Android Developer to join our dynamic team.",
            requirements = listOf(
                "5+ years of Android development experience",
                "Strong knowledge of Kotlin and Java",
                "Experience with Jetpack Compose"
            ),
            postedDate = "2 days ago",
            category = "Technology"
        ),
        Job(
            id = 2,
            title = "UI/UX Designer",
            company = "Creative Minds Studio",
            location = "Mumbai, Maharashtra",
            salary = "₹8-15 LPA",
            type = "Full-time",
            description = "Join our creative team as a UI/UX Designer.",
            requirements = listOf(
                "3+ years of UI/UX design experience",
                "Proficiency in Figma, Adobe XD"
            ),
            postedDate = "1 week ago",
            category = "Design"
        ),
        Job(
            id = 3,
            title = "Full Stack Developer",
            company = "StartUp Innovations",
            location = "Hyderabad, Telangana",
            salary = "₹12-20 LPA",
            type = "Full-time",
            description = "Build scalable web applications.",
            requirements = listOf(
                "4+ years of full stack development",
                "Proficiency in React.js and Node.js"
            ),
            postedDate = "3 days ago",
            category = "Technology"
        )
    )

    fun getJobById(id: Int): Job? = jobs.find { it.id == id }

    fun searchJobs(query: String): List<Job> {
        if (query.isEmpty()) return jobs
        return jobs.filter {
            it.title.contains(query, ignoreCase = true) ||
                    it.company.contains(query, ignoreCase = true) ||
                    it.location.contains(query, ignoreCase = true)
        }
    }
}